//#include <stdio.h>
//int main() {
//	int i, number,a,b,d,e;
//
//	printf("Enter a five-digit number: ");
//	scanf_s("%d", &number);
//
//	a = number / 10000;
//	b = (number / 1000) % 10;
//	d = (number / 10) % 10;
//	e = number % 10;
//
//	if (a == e || b == d) {
//		printf("%d is a palindrome\n",number);
//	}
//	else {
//		printf("%d is not a palindrome\n",number);
//	}
//}