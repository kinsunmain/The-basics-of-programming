//#include <stdio.h>
//int main() {
//	int i = 0, number, a, b, c, d, e, cnt = 0;
//
//	printf("Enter a 5-digit number: ");
//	scanf_s("%d", &number);
//
//	a = number / 10000;
//	b = (number / 1000) % 10;
//	c = (number / 100) % 10;
//	d = (number / 10) % 10;
//	e = number % 10;
//
//	if (a == 7) cnt += 1;
//	if (b == 7) cnt += 1;
//	if (c == 7) cnt += 1;
//	if (d == 7) cnt += 1;
//	if (e == 7) cnt += 1;
//
//	printf("The number %d has %d seven(s) in it\n", number, cnt);
//}
//
//	
