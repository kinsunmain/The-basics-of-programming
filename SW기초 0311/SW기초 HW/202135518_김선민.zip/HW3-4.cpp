//#include <stdio.h>
//int main() {
//	float n,total=1;
//	int p, i;
//
//	printf("Type a positive float number (N): ");
//	scanf_s("%f", &n);
//	printf("Type an integer number (P): ");
//	scanf_s("%d", &p);
//
//	for (i = 1; i <= p; i++) {
//		total = total * n;
//	}
//	printf("Result is %f\n", total);
//}